const express = require('express');
const router = express.Router();
const controller = require("../controllers/userController");

//Render your view files here
router.get("/", controller.indexPage);
router.post("/user", controller.userPage);
router.post("/return",controller.return)

module.exports = router;
