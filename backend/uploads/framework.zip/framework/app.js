const express = require("express");
const bodyParser = require('body-parser');
const app = express();
const userRoute = require('./routes/user')
const session = require('express-session');
const http = require('http').Server(app);
const connection = require("./db_settings/config"); // Create an HTTP server
//const io = require('socket.io')(http); // Pass the HTTP server to socket.io

app.use(session({
  secret: 'keyboardkitteh',
  resave: false,
 saveUninitialized: true,
  cookie: { maxAge: 60000 }
}));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/', userRoute);

app.use('/assets', express.static(__dirname + '/assets'));

app.set('view engine', 'ejs');

http.listen(8888, function() {
    console.log("Server is listening on port 8888");
});
