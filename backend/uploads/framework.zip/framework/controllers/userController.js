class User {

    indexPage(req, res) {
        res.render('index');
    }

    userPage(req, res) {
        const { name, course_title, score, message } = req.body;
        //req.session.data= {
           // name: name,
           // course_title: course_title,
            //score: score,
            //message: message
        //};
        //console.log( req.session.data);
        console.log( req.body);
        res.render('userpage', { data: req.body });
       
    }
    
    return(req, res) {
        res.redirect('/');
    }
 
}

module.exports = new User();
