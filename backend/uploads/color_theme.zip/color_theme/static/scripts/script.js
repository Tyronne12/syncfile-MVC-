$(document).ready(function (){
    const socket = io();

    // Function to send a message to the server when the form is submitted
    $('#light_mode').click(function(event) {
        var color = 'white';
        socket.emit('select_light_mode', color); 
    });

    $('#dark_mode').click(function(event) {
        var color = 'rgb(57, 57, 57)';
        socket.emit('select_dark_mode', color); 
    });
    
    $('#random_mode').click(function(event) {
        const rgb = ['a','b','c','d','e','f','0','1','2','3','4','5','6','7','8','9'];
        let color = '#' 
        for(let i = 0; i < 6; i++)  
        {
            let x = Math.floor((Math.random()*16));  
            color += rgb[x]; 
        }
        socket.emit('select_random_mode', color); 
    });        


    socket.on('updated_color', function(color) {
        console.log('Message from server:', color);
        if(color == 'white'){
            $('body').css({
                'background-color': color,
                'color': 'black'
            });
        }
        else if(color == 'rgb(57, 57, 57)')   {
            $('body').css({
                'background-color': color,
                'color': 'white'
            });
        } 
        else{
            $('body').css({
                'background-color': color,
                'color': 'black'
            });
        }
    });

});