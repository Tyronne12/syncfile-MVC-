const express = require("express");
const bodyParser = require('body-parser');
const app = express();
const session = require('express-session');
const { Console } = require("console");
const http = require('http').Server(app); // Create an HTTP server
const io = require('socket.io')(http); // Pass the HTTP server to socket.io


app.use(session({
  secret: 'keyboardkitteh',
  resave: false,
  saveUninitialized: true,
  cookie: { maxAge: 60000 }
}));

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use('/static', express.static(__dirname + '/static'));

app.set('view engine', 'ejs');
app.get('/', function (req, res){
    res.render('index', { title: "My Express project" });
});

io.on('connection', function (socket) {
    console.log('Client connected.');

    socket.on('select_light_mode', function(data) {
        console.log('Color:', data);
        io.emit('updated_color', data);
    });
    socket.on('select_dark_mode', function(data) {
        console.log('Color:', data);
        io.emit('updated_color', data);
    });
    socket.on('select_random_mode', function(data) {
        console.log('Color:', data);
        io.emit('updated_color', data);
    });
});

http.listen(8080, function() {
    console.log("Server is listening on port 8080");
});
